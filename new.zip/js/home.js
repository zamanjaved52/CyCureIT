/*navbar*/
function openNav() {
    document.getElementById("mySidenav_sc").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav_sc").style.width = "0";
}

/*/navbar*/
